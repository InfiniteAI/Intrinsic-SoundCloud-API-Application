$(function() {
    $('.toggler').click(function() {
        $(this).find('div').slideToggle();
    });
});